# 🚀 StudyHub — Complete Deployment Guide
## Vercel (Frontend) + Railway/Render (Backend) + MongoDB Atlas (Database)

---

## 📋 Prerequisites

- Node.js 18+
- Git & GitHub account
- [Vercel account](https://vercel.com) (free)
- [MongoDB Atlas account](https://cloud.mongodb.com) (free tier)
- [Railway account](https://railway.app) OR [Render account](https://render.com) (for backend)

---

## Step 1 — MongoDB Atlas Setup

1. Go to [cloud.mongodb.com](https://cloud.mongodb.com) and sign in
2. Click **"Build a Database"** → choose **FREE (M0 Sandbox)**
3. Select a cloud provider (AWS recommended) and region closest to you
4. Click **"Create Cluster"** (takes 1–3 min)

### Create Database User
1. In the left sidebar → **Database Access** → **Add New Database User**
2. Choose **Password** authentication
3. Username: `studyhub_user`, generate a strong password (save it!)
4. Role: **Atlas Admin** (or `readWriteAnyDatabase`)
5. Click **Add User**

### Whitelist IP
1. **Network Access** → **Add IP Address**
2. Click **"Allow Access from Anywhere"** → `0.0.0.0/0`
   *(For production, restrict to your backend server IPs)*
3. Click **Confirm**

### Get Connection String
1. **Database** → **Connect** → **Connect your application**
2. Driver: Node.js, Version: 4.1 or later
3. Copy the connection string — it looks like:
   ```
   mongodb+srv://studyhub_user:<password>@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority
   ```
4. Replace `<password>` with your actual password
5. Add your database name: `...mongodb.net/studyhub?retryWrites=true...`

---

## Step 2 — Backend Deployment (Railway)

### Option A: Railway (Recommended)

1. Go to [railway.app](https://railway.app) → sign in with GitHub
2. Click **"New Project"** → **"Deploy from GitHub repo"**
3. Select your StudyHub repo → select the `backend` folder
4. Railway auto-detects Node.js

### Set Environment Variables in Railway
Go to your project → **Variables** tab → add each:

```env
NODE_ENV=production
PORT=5000
MONGODB_URI=mongodb+srv://studyhub_user:PASSWORD@cluster0.xxxxx.mongodb.net/studyhub?retryWrites=true&w=majority
JWT_SECRET=your_super_secret_jwt_key_min_32_chars_random_string_here
JWT_EXPIRE=7d
CLIENT_URL=https://your-studyhub.vercel.app
CLOUDINARY_CLOUD_NAME=your_cloudinary_name
CLOUDINARY_API_KEY=your_cloudinary_key
CLOUDINARY_API_SECRET=your_cloudinary_secret
```

> **JWT_SECRET**: Generate with `node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"`

5. Railway will auto-deploy. Copy your **Railway URL** (e.g., `https://studyhub-backend.up.railway.app`)

### Option B: Render

1. Go to [render.com](https://render.com) → **New** → **Web Service**
2. Connect GitHub repo, set **Root Directory** to `backend`
3. Build Command: `npm install`
4. Start Command: `npm start`
5. Add the same environment variables above
6. Copy your Render URL

---

## Step 3 — Frontend Deployment (Vercel)

### Option A: Vercel CLI

```bash
# Install Vercel CLI
npm install -g vercel

# In the project root
cd studyhub/frontend

# Build first
npm install
npm run build

# Deploy
vercel

# Follow prompts:
# - Set up and deploy? Yes
# - Which scope? (your username)
# - Link to existing project? No
# - Project name: studyhub
# - Directory: ./  (you're already in frontend/)
# - Override build settings? No
```

### Option B: Vercel Dashboard (Easier)

1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com) → **New Project**
3. Import your GitHub repository
4. **Configure Project:**
   - Framework Preset: **Create React App**
   - Root Directory: `frontend`
   - Build Command: `npm run build`
   - Output Directory: `build`

### Set Environment Variables in Vercel
Go to your project → **Settings** → **Environment Variables**:

```env
REACT_APP_API_URL=https://your-studyhub-backend.up.railway.app/api
REACT_APP_SOCKET_URL=https://your-studyhub-backend.up.railway.app
```

5. Click **Deploy** → wait ~2 minutes
6. Your site will be live at `https://studyhub-xxxx.vercel.app`

---

## Step 4 — Connect Frontend ↔ Backend

### Update Backend CORS
In your Railway/Render **environment variables**, update:
```env
CLIENT_URL=https://your-actual-vercel-url.vercel.app
```

Then in `backend/src/app.js`, verify CORS is set correctly:
```javascript
origin: process.env.CLIENT_URL || 'http://localhost:3000'
```

### Custom Domain (Optional)
1. In Vercel → **Settings** → **Domains** → Add your domain
2. Update your DNS records as shown by Vercel
3. Update `CLIENT_URL` in Railway to your custom domain

---

## Step 5 — File Uploads with Cloudinary (Optional)

If you want file uploads to work in production (Cloudinary is free):

1. Sign up at [cloudinary.com](https://cloudinary.com)
2. Dashboard → copy **Cloud Name**, **API Key**, **API Secret**
3. Add to Railway environment variables:
   ```env
   CLOUDINARY_CLOUD_NAME=dxxxxxxxx
   CLOUDINARY_API_KEY=123456789012345
   CLOUDINARY_API_SECRET=your_api_secret_here
   ```

---

## Step 6 — Verify Everything Works

Test these endpoints:
```bash
# Health check
curl https://your-backend.up.railway.app/health

# Register a user
curl -X POST https://your-backend.up.railway.app/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","email":"test@example.com","password":"password123"}'
```

---

## 🛠️ Local Development

```bash
# Clone and set up
git clone https://github.com/your/studyhub.git
cd studyhub

# Backend
cd backend
cp .env.example .env
# Edit .env with your local MongoDB URI and JWT_SECRET
npm install
npm run dev    # Starts on :5000

# Frontend (new terminal)
cd ../frontend
npm install
npm start      # Starts on :3000 with proxy to :5000
```

---

## 📁 Environment Files

### `backend/.env`
```env
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/studyhub
JWT_SECRET=dev_secret_change_in_production_min_32_chars
JWT_EXPIRE=7d
CLIENT_URL=http://localhost:3000
```

### `frontend/.env.local`
```env
REACT_APP_API_URL=http://localhost:5000/api
REACT_APP_SOCKET_URL=http://localhost:5000
```

---

## 🔒 Security Checklist

- [ ] `JWT_SECRET` is long (64+ chars) and random
- [ ] MongoDB password is strong and unique
- [ ] CORS is restricted to your Vercel domain
- [ ] Rate limiting is enabled in backend
- [ ] `NODE_ENV=production` is set
- [ ] Cloudinary API keys are not in frontend code
- [ ] `.env` files are in `.gitignore`

---

## 🐛 Common Issues

| Problem | Solution |
|---|---|
| CORS errors | Check `CLIENT_URL` env var matches Vercel URL exactly (no trailing slash) |
| WebSocket not connecting | Ensure `REACT_APP_SOCKET_URL` points to backend, not `/api` |
| MongoDB connection fails | Check IP whitelist in Atlas, verify password in connection string |
| 404 on page refresh | Vercel SPA rewrite is set — check `vercel.json` rewrites |
| Build fails on Vercel | Ensure `frontend/package.json` has all deps in `dependencies` not `devDependencies` |
| File uploads fail | Set up Cloudinary env vars in Railway |

---

## 📊 Free Tier Limits

| Service | Free Limit |
|---|---|
| Vercel | 100GB bandwidth, unlimited deployments |
| MongoDB Atlas M0 | 512MB storage, shared cluster |
| Railway | $5 free credit/month (~500 hours) |
| Render | 750 hours/month (spins down after inactivity) |
| Cloudinary | 25GB storage, 25GB bandwidth/month |

> **Tip:** Railway is preferred over Render for backend because Render free tier spins down after 15 min of inactivity (slow first request). Railway stays live.

---

## ✅ Deployment Checklist

- [ ] MongoDB Atlas cluster created and user added
- [ ] Backend deployed to Railway/Render
- [ ] All backend environment variables set
- [ ] Backend health check returns 200
- [ ] Frontend deployed to Vercel
- [ ] Frontend env vars point to backend URL
- [ ] CORS allows Vercel domain
- [ ] Register/Login works in production
- [ ] WebSocket connection shows "Connected" in sidebar
- [ ] Create a room and test real-time chat

---

*StudyHub is now live! 🎉*
